import React from 'react';
import { JobData } from '../types';
import InfoRow from './InfoRow';
import { MapPinIcon } from './IconComponents';

interface JobViewProps {
  job: JobData;
}

const JobView: React.FC<JobViewProps> = ({ job }) => {
  return (
    <div className="space-y-4">
        <dl>
            <InfoRow label="Role" value={job.role} icon="🧑‍💻" />
            <InfoRow label="Company" value={job.company} icon="🏢" />
            {job.companyDescription && <p className="text-sm text-gray-400 py-3 px-1">{job.companyDescription}</p>}
            <InfoRow 
                label="Location" 
                value={job.location} 
                icon="📍"
                action={job.location ? {
                    icon: <MapPinIcon className="w-5 h-5"/>,
                    onClick: () => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(job.location!)}`, '_blank'),
                    ariaLabel: 'View location on map'
                } : undefined}
            />
            <InfoRow label="Type" value={job.jobType} icon="📄" />
            <InfoRow label="Work Mode" value={job.workMode} icon="🏠" />
            <InfoRow label="Salary" value={job.salary} icon="💰" />
            <InfoRow label="Experience" value={job.experience} icon="📈" />
            <InfoRow label="Education" value={job.education} icon="🎓" />
            <InfoRow 
                label="Skills" 
                value={
                    job.skillsRequired && job.skillsRequired.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                            {job.skillsRequired.map((skill, index) => (
                                <span key={index} className="text-xs px-2 py-1 rounded-full bg-blue-500/20 text-blue-300">
                                    {skill}
                                </span>
                            ))}
                        </div>
                    ) : undefined
                } 
                icon="🛠️"
            />
            <InfoRow 
                label="Responsibilities"
                value={
                    job.responsibilities && job.responsibilities.length > 0 ? (
                        <ul className="list-disc list-inside space-y-1">
                            {job.responsibilities.map((item, index) => <li key={index}>{item}</li>)}
                        </ul>
                    ) : undefined
                }
                icon="📋"
            />
            <InfoRow 
                label="Qualifications"
                value={
                    job.qualifications && job.qualifications.length > 0 ? (
                        <ul className="list-disc list-inside space-y-1">
                            {job.qualifications.map((item, index) => <li key={index}>{item}</li>)}
                        </ul>
                    ) : undefined
                }
                icon="✅"
            />
            <InfoRow 
                label="Benefits"
                value={
                    job.benefits && job.benefits.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                            {job.benefits.map((benefit, index) => (
                                <span key={index} className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-300">
                                    {benefit}
                                </span>
                            ))}
                        </div>
                    ) : undefined
                }
                icon="🎁"
            />
            <InfoRow label="Apply by" value={job.deadline} icon="⏳" />
            <InfoRow 
                label="Apply At" 
                value={
                    job.applyLink ? (
                        <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline break-all">
                            {job.applyLink}
                        </a>
                    ) : undefined
                }
                icon="🔗"
            />
        </dl>
    </div>
  );
};

export default JobView;